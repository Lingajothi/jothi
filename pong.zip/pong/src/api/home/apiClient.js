import axios from "axios";

const AXIOS = axios.create({
    baseURL: `https://api.sfd.interview.ovckd.dev`,
});

AXIOS.defaults.headers.common["Authorization"] = `1251a1de9906a858d1fc697792a5f5a7065a5fe984a159b1d3c3bbea160aa39b`;

export const Axios = AXIOS;