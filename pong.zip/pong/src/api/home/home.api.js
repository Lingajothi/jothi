import { Axios } from "./apiClient";
export const getMessage = () => {
    return Axios.get(`/v1/ping/`)
}

export const getUser = () => {
    return Axios.get(`/v1/user/`)
}
export const getLoans = () => {
    return Axios.get(`/v1/user/applications`)
}
export const getOffers = () => {
    return Axios.get(`/v1/user/applications/1/offers`)
}