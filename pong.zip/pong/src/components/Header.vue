<script setup>
import { ref, onMounted } from "vue";
import { getMessage, getUser } from "../api/home/home.api";

let message = ref([]);
let userData = ref([]);
onMounted(async () => {
  messageLoad();
  userLoad();
});
// Message List API Call
async function messageLoad() {
  message.value = await (await getMessage()).data;
}
// UserData List API Call
async function userLoad() {
  userData.value = await (await getUser()).data;
}
</script>

<template>
  <div
    class="block sm:flex justify-between items-center p-[20px] sticky top-0 bg-[#4f46e5]"
  >
    <router-link :to="`/`">
      <h1
        class="sm:text-3xl text-xl font-bold capitalize text-white mb-[12px] sm:mb-[0]"
      >
        {{ message.message }}
      </h1>
    </router-link>

    <div class="flex items-center">
      <img src="../assets/profile.png" alt="User" />
      <div class="ml-[12px]">
        <p class="font-semibold text-white">{{ userData.name }}</p>
        <p class="font-semibold text-white">{{ userData.email }}</p>
      </div>
    </div>
  </div>
</template>

<style scoped></style>
