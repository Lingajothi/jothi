<template>
  <div
    class="fixed bottom-0 bg-[#4f46e5] p-[12px] w-full text-white text-center font-semibold"
  >
    Copyright &copy; 2023 pong
  </div>
</template>
