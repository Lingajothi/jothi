<script setup>
import { ref, onMounted } from "vue";
import { getLoans } from "../api/home/home.api";
let loans = ref([]);
onMounted(async () => {
  loanLoad();
});
// Loans List API Call
async function loanLoad() {
  loans.value = await (await getLoans()).data;
}
</script>

<template>
  <div class="sm:p-[32px] p-[20px]">
    <h2 class="text-2xl font-bold mb-[24px]">Loan Applications</h2>
    <ul class="grid gap-4 sm:grid-cols-3 grid-cols-1 w-full mb-[80px]">
      <li
        style="box-shadow: 0px 0px 19px rgb(204 204 204 / 25%)"
        v-for="(loan, index) in loans"
        :id="index + 1"
        :key="index"
        class="border border-[#f2f2f2] rounded-[12px] p-[20px] bg-[#fff]"
      >
        <p class="text-xl font-bold mb-[16px]">{{ loan.university }}</p>
        <h3 class="font-semibold mb-[32px] flex items-center text-xl">
          Amount:
          <p
            class="mb-[0px] ml-[12px] bg-[#bbf7d0] w-fit rounded-[4px] py-[4px] px-[8px] font-medium text-[#16a34a]"
          >
            ₹ {{ loan.loan_amount }}
          </p>
        </h3>
        <router-link
          :to="`/loan-list/${index + 1}`"
          class="bg-[#4f46e5] w-fit border border-[#4f46e5] text-white text-center px-[12px] py-[8px] rounded flex justify-center mx-auto font-semibold transition-colors hover:bg-[#fff] hover:text-[#4f46e5]"
        >
          <button class="bg-transparent">View Offers</button>
        </router-link>
      </li>
    </ul>
  </div>
</template>

<style scoped></style>
