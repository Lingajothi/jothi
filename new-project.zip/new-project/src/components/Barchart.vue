<template>
    <Bar
      id="my-chart-id"
      :options="chartOptions"
      :data="chartData"
    />
  </template>
  
  <script>
  import { Bar } from 'vue-chartjs'
  import {
  Chart as ChartJS,
  Title,
  Tooltip,
  Legend,
  BarElement,
  CategoryScale,
  LinearScale
} from 'chart.js'  
ChartJS.register(CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend)


  export default {
    name: 'Barchart',
    components: { Bar },
    data() {
      return {
        chartData: {
          labels: [ 'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec' ],
          datasets: [
    {
      label: 'Workflow',
      backgroundColor: '#1094be',
      borderColor: "#1094be",
      data: [40, 39, 10, 40, 39, 80, 40, 90, 150, 80, 50, 40]
    }
  ]
        },
        chartOptions: {
            scales: {
                x: {
                    display: true,
                    grid: {
                        display: false
                    }
                },
                y: {
                    display: false,
                }
            },
            responsive: true,
            plugins: {
                legend: {
                    display: false
                },
                
            }
   
        },
        
      }
    }
  }
  </script>