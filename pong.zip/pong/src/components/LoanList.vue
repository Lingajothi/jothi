<script setup>
import { ref, onMounted } from "vue";
import { getOffers } from "../api/home/home.api";
import Header from "../components/Header.vue";
import Footer from "../components/Footer.vue";

let offers = ref([]);
onMounted(async () => {
  offersLoad();
});
// Offers List API Call
async function offersLoad() {
  offers.value = await (await getOffers()).data;
  let sortedProducts = offers.value.sort((p1, p2) =>
    p1.interest_rate > p2.interest_rate
      ? 1
      : p1.interest_rate < p2.interest_rate
      ? -1
      : 0
  );
}
</script>

<template>
  <div>
    <Header />
    <div class="sm:p-[32px] p-[20px]">
      <div class="flex justify-between">
        <h2 class="text-2xl font-bold mb-[24px]">Loan Offers</h2>
        <router-link :to="`/`">
          <img src="../assets/back.png" class="w-[32px]" />
        </router-link>
      </div>

      <ul class="grid gap-4 sm:grid-cols-3 grid-cols-1 w-full mb-[80px]">
        <li
          style="box-shadow: 0px 0px 19px rgb(204 204 204 / 25%)"
          v-for="(offer, index) in offers"
          :key="index"
          class="border border-[#f2f2f2] rounded-[12px] p-[20px] bg-[#fff]"
        >
          <img
            :src="offer.bank_logo"
            class="mb-[20px] w-[full] h-[30px]"
            :alt="offer.bank"
          />
          <p class="text-xl font-bold mb-[12px]">{{ offer.bank }}</p>
          <div class="flex justify-between items-center">
            <p>
              <span class="font-semibold">Interest:</span>
              {{ offer.interest_rate }}%
            </p>
            <p>
              <span class="font-semibold">Tenure:</span>
              {{ offer.tenure }} Months
            </p>
          </div>
        </li>
      </ul>
    </div>
    <Footer />
  </div>
</template>

<style scoped></style>
