<script setup>
import {ref} from 'vue'
import Linechart from '/src/components/Linechart.vue'
import Barchart from '/src/components/Barchart.vue'

const items = ref(
    [
        { name: 'Document', amount:'146.000', percentage:'17 %', content: 'Since last week'},
        { name: 'Contact', amount: '1400', percentage:'20 %', content: 'Since last monday'},
        { name: 'Email', amount: '150.700', percentage:'30 %', content: 'Since last week'}
    ]
)

const table_datas = ref(
    [
        { name: 'Annual Report', file:'PDF', category:'Property', author: 'Diana Mattews', status:'Send'},
        { name: 'Business Plan', file:'WORD', category:'Cryptocurency', author: 'Philip James', status:'Send'},
        { name: 'Markrting Tool', file:'PDF', category:'Content Creater', author: 'Amanda Ross', status:'Pending'},
    ]
)


</script>
<template>
    <div class="data_main_block">
        <div class="data_block" v-for="(item, index) in items" :key="index">
            <div class="data_heading">
                <h3>{{item.name}}</h3>
                <div class="icon_block">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512" width="20px" height="20px">
                        <path d="M64 0C28.7 0 0 28.7 0 64V448c0 35.3 28.7 64 64 64H320c35.3 0 64-28.7 64-64V160H256c-17.7 0-32-14.3-32-32V0H64zM256 0V128H384L256 0zM111 257.1l26.8 89.2 31.6-90.3c3.4-9.6 12.5-16.1 22.7-16.1s19.3 6.4 22.7 16.1l31.6 90.3L273 257.1c3.8-12.7 17.2-19.9 29.9-16.1s19.9 17.2 16.1 29.9l-48 160c-3 10-12 16.9-22.4 17.1s-19.8-6.2-23.2-16.1L192 336.6l-33.3 95.3c-3.4 9.8-12.8 16.3-23.2 16.1s-19.5-7.1-22.4-17.1l-48-160c-3.8-12.7 3.4-26.1 16.1-29.9s26.1 3.4 29.9 16.1z"/>
                    </svg>
                </div>
            </div>
            <h1>{{ item.amount }}</h1>
            <div class="data_bottom_block">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 576 512" width="20px" height="20px">
                    <path d="M384 160c-17.7 0-32-14.3-32-32s14.3-32 32-32H544c17.7 0 32 14.3 32 32V288c0 17.7-14.3 32-32 32s-32-14.3-32-32V205.3L342.6 374.6c-12.5 12.5-32.8 12.5-45.3 0L192 269.3 54.6 406.6c-12.5 12.5-32.8 12.5-45.3 0s-12.5-32.8 0-45.3l160-160c12.5-12.5 32.8-12.5 45.3 0L320 306.7 466.7 160H384z"/>
                </svg>
                <span>{{ item.percentage }}</span>
                <p>{{ item.content }}</p>
            </div>
           
        </div>
        <div class="recent_block">
            <div class="recent_data">
                <h3>Recent Workflow</h3>
                <div class="recent_percentage_block">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 576 512" width="20px" height="20px">
                    <path d="M384 160c-17.7 0-32-14.3-32-32s14.3-32 32-32H544c17.7 0 32 14.3 32 32V288c0 17.7-14.3 32-32 32s-32-14.3-32-32V205.3L342.6 374.6c-12.5 12.5-32.8 12.5-45.3 0L192 269.3 54.6 406.6c-12.5 12.5-32.8 12.5-45.3 0s-12.5-32.8 0-45.3l160-160c12.5-12.5 32.8-12.5 45.3 0L320 306.7 466.7 160H384z"/>
                </svg>
                <span>17 %</span>
                </div>
                <Linechart />
            </div>
            <div class="recent_data">
                <h3>Recent Marketing</h3>
                <div class="recent_percentage_block">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 576 512" width="20px" height="20px">
                    <path d="M384 160c-17.7 0-32-14.3-32-32s14.3-32 32-32H544c17.7 0 32 14.3 32 32V288c0 17.7-14.3 32-32 32s-32-14.3-32-32V205.3L342.6 374.6c-12.5 12.5-32.8 12.5-45.3 0L192 269.3 54.6 406.6c-12.5 12.5-32.8 12.5-45.3 0s-12.5-32.8 0-45.3l160-160c12.5-12.5 32.8-12.5 45.3 0L320 306.7 466.7 160H384z"/>
                </svg>
                <span>17 %</span>
                </div>
                <Barchart />
            </div>
        </div>
        <div class="data_main">
            <div class="data_table">
                <div class="data_heading">
                    <div>
                        <h3>Document</h3>
                    <span>Document tracking information</span>
                    </div>
                    
                    <ul class="primary-menus">
                        <li class="menus-dropdown">
                            <a href="#">Weekly 
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512" width="16px" height="16px">
                                    <path d="M201.4 342.6c12.5 12.5 32.8 12.5 45.3 0l160-160c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0L224 274.7 86.6 137.4c-12.5-12.5-32.8-12.5-45.3 0s-12.5 32.8 0 45.3l160 160z"/>
                                </svg>
                            </a>
                            <ul class="dropdown">
                                <li><a href="#">Last Month</a></li>
                                <li><a href="#">Monthly</a></li>
                                <li><a href="#">Yearly</a></li>
                            </ul>
                        </li>
                    </ul>
                </div>
                <div class="table_block">
                    <table>
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>File</th>
                                <th>Category</th>
                                <th>Author</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr v-for="table_data in table_datas" :key="index">
                                <td>{{ table_data.name }}</td>
                                <td>{{ table_data.file }}</td>
                                <td>{{ table_data.category }}</td>
                                <td>{{ table_data.author }}</td>
                                <td><button :class="table_data.status === 'Send' ? 'send' : 'pending'">{{ table_data.status }}</button></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    
  
</template>