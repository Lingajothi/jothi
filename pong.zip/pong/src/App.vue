<template>
  <RouterView />
</template>
<script setup>
import { RouterView } from "vue-router";
import "./assets/css/style.css";
</script>
