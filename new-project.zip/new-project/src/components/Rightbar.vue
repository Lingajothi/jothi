<script setup>
import {ref} from 'vue'

const items = ref(
    [
        { name: 'Gadget Converter', amount:'$250'},
        { name: 'Lens Camera', amount:'$50'},
        { name: 'Airpods', amount:'$100'},
        { name: 'Macbook', amount:'$999'},
    ]
)
const chats = ref(
    [
        { name: 'Debra Young', content:'How my product?'},
        { name: 'Dorothy Collins', amount:'How are the meeting'},
        { name: 'Chirs Jordon', amount:'How employee performance'},
        { name: 'Denise Murphy', amount:'How was the meeting'},
    ]
)

</script>
<template>
    <div class="right_block">
        <h3>Popular</h3>
        <div class="right_content_block" v-for="(item, index) in items" :key="index">
            <div class="right_circle_block"></div>
            <div class="right_data_block">
                <h4>{{ item.name }}</h4>
            <p>{{ item.amount }}</p>
            </div>
        </div>
        <h3>Chat</h3>
        <div class="right_content_block" v-for="(chat, index) in chats" :key="index">
            <div class="right_circle_block"></div>
            <div class="right_data_block">
                <h4>{{ chat.name }}</h4>
            <p>{{ chat.content }}</p>
            </div>
            
        </div>
    </div>
</template>