<script setup>
import Header from "../components/Header.vue";
import Footer from "../components/Footer.vue";
import LoanApplications from "../components/LoanApplications.vue";
</script>

<template>
  <div>
    <Header />
    <LoanApplications />
    <Footer />
  </div>
</template>

<style scoped></style>
