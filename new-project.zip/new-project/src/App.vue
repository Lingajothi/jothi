<script setup>
import Sidebar from '/src/components/Sidebar.vue'
import Mainsection from '/src/components/Mainsection.vue'
import Mobilemenu from '/src/components/Mobilemenu.vue'
</script>

<template>
  <div class="main_container">
    <Sidebar msg="CRM.io" />
    <Mobilemenu/>
    <Mainsection/>
  </div>
 
  
</template>

