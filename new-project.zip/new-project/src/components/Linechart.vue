<template>
    <Line
      id="my-chart-id"
      :options="chartOptions"
      :data="chartData"
    />
  </template>
  
  <script>
  import { Line } from 'vue-chartjs'
  import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
} from 'chart.js'  
  ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
)

  export default {
    name: 'Linechart',
    components: { Line },
    data() {
      return {
        chartData: {
          labels: [ 'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec' ],
          datasets: [
    {
      label: 'Workflow',
      backgroundColor: '#1094be',
      borderColor: "#1094be",
      data: [40, 39, 10, 40, 39, 80, 40, 90, 150, 80, 50, 40]
    }
  ]
        },
        chartOptions: {
            scales: {
                x: {
                    display: true,
                    grid: {
                        display: false
                    }
                },
                y: {
                    display: false,
                }
            },
            responsive: true,
            plugins: {
                legend: {
                    display: false
                },
                
            }
   
        },
        
      }
    }
  }
  </script>